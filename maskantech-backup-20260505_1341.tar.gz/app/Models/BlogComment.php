<?php
// ════════════════════════════════════════════════════════════════════════════
//  app/Models/BlogComment.php
// ════════════════════════════════════════════════════════════════════════════
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class BlogComment extends Model
{
    protected $fillable = ['post_id', 'user_id', 'content', 'status'];

    public function post() { return $this->belongsTo(BlogPost::class, 'post_id'); }
    public function user() { return $this->belongsTo(User::class); }
}
